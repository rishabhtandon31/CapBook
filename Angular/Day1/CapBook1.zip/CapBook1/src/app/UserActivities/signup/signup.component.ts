import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServices } from 'src/app/services/capbook.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  firstName:string;
  lastName:string;
  dateOfBirth:string;
  password:string;
	emailID:string;
  age:number;
	mobileNo:number;
  gender:string;
  errorMessage: string;
  constructor(private route:ActivatedRoute,private router:Router,private service:CapbookServices) { }

  get _firstName():string{
    return this.firstName;
  }
  set _firstName(value:string){
    this.firstName=value;
  }
  get _lastName():string{
    return this.lastName;
  }
  set _lastName(value:string){
    this.lastName=value;
  }
  get _dateOfBirth():string{
    return this.dateOfBirth;
  }
  set _dateOfBirth(value:string){
    this.dateOfBirth=value;
  }
  get _password():string{
    return this.password;
  }
  set _password(value:string){
    this.password=value;
  }
  get _emailID():string{
    return this.emailID;
  }
  set _emailID(value:string){
    this.emailID=value;
  }
  get _age():number{
    return this.age;
  }
  set _age(value:number){
    this.age=value;
  }
  get _mobileNo():number{
    return this.mobileNo;
  }
  set _mobileNo(value:number){
    this.mobileNo=value;
  }
  get _gender():string{
    return this.gender;
  }
  set _gender(value:string){
    this.gender=value;
  }
  ngOnInit() {
  }
  
  onClick(){
    const _user:any={
      firstName:this._firstName,
      lastName:this._lastName,
      dateOfBirth:this._dateOfBirth,
      password:this._password,
      emailID:this._emailID,
      age:this._age,
      mobileNo:this._mobileNo,
      gender:this._gender
    }
    this.service.acceptUserDetails(_user).subscribe(
      tempMessage=>{
        //this.addMessage="Product Added Successfully!!"; 
        
        } 
    ,
      error=>{
        this.errorMessage=error;
      }
  );
  }

}
