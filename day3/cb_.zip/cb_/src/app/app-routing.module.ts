import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { WelcomeComponent } from './UserActivities/welcome/welcome.component';
import { DashboardComponent } from './UserActivities/dashboard/dashboard.component';
import { SigninComponent } from './UserActivities/signin/signin.component';
import { SignupComponent } from './UserActivities/signup/signup.component';
import { ForgotPasswordComponent } from './UserActivities/forgotPassword/forgot-password.component';
import { ProfileComponent } from './UserActivities/dashboard/profile/profile.component';
import { AboutComponent } from './UserActivities/dashboard/profile/about/about.component';

const routes: Routes = [
  {path: 'welcome', component: WelcomeComponent},
  {path: 'dashboard', component: DashboardComponent},
{path: 'signin', component: SigninComponent },
{path: 'signup',component:SignupComponent},
{path: 'forgotPassword', component: ForgotPasswordComponent},
{path: 'profilePage', component: ProfileComponent},
{path: 'aboutPage', component: AboutComponent},
{path: '', redirectTo: 'welcome', pathMatch: 'full'},
{
  path: 'layout',
  loadChildren: './layout/layout.module#LayoutModule'
}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
