import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServicesService } from 'src/app/services/capbook-services.service';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {
_answer1:string;
_answer2:string;
_dob:string;
_emailID:string;
_newPassword:string;
_confirmPassword:string;
_message:string;
_error:string;

  constructor(private route:ActivatedRoute, private router: Router, private capbookServices: CapbookServicesService) { }

  get emailID():string {
    return this._emailID;
}
set emailID(value:string) {
  this._emailID = value;
}


get answer1():string {
  return this._answer1;
}
set answer1(value:string) {
this._answer1 = value;
}

get answer2():string {
  return this._answer2;
}
set answer2(value:string) {
this._answer2 = value;
}

get dob():string {
  return this._dob;
}
set dob(value:string) {
this._dob = value;
}

get newPassword():string {
  return this._newPassword;
}
set newPassword(value:string) {
this._newPassword = value;
}

get confirmPassword():string {
  return this._confirmPassword;
}
set confirmPassword(value:string) {
this._confirmPassword = value;
}

  ngOnInit() {
  }

  forgotPassword(){
    const user1:any={
      emailID:this.emailID,
      dob:this.dob,
      newPassword:this.newPassword,
      confirmPassword:this.confirmPassword
    }

    this.capbookServices.forgotPassword(user1).subscribe(
      tempmessage=>{
        this._message="You have succesfully reset your password.";
        console.log(this._message);
      },
      error=>{
        this._error=error;
        console.log("error");
      }
    );
  }

}
