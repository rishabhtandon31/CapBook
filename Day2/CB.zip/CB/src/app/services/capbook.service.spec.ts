import { TestBed } from '@angular/core/testing';

import { CapbookService } from './capbook.service';

describe('CapbookService', () => {
  beforeEach(() => TestBed.configureTestingModule({}));

  it('should be created', () => {
    const service: CapbookService = TestBed.get(CapbookService);
    expect(service).toBeTruthy();
  });
});
