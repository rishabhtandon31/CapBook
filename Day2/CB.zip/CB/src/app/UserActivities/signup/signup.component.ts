import { Component, OnInit } from '@angular/core';
import { ActivatedRoute, Router } from '@angular/router';
import { CapbookServices } from 'src/app/services/capbook.service';


@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  _firstName:string;
  _lastName:string;
  _dateOfBirth:string;
  _password:string;
	_emailID:string;
  _age:number;
	_mobileNo:number;
  _gender:string;
  _firstSecurityAnswer: string;
  _secondSecurityAnswer: string;
  errorMessage: string;
  successMessage:string;
  genderList: string[] = ['Male', 'Female'];
  
  constructor(private route:ActivatedRoute,private router:Router,private service:CapbookServices) { }

  get firstName():string{
    return this._firstName;
  }
  set firstName(value:string){
    this._firstName=value;
  }
  get lastName():string{
    return this._lastName;
  }
  set lastName(value:string){
    this._lastName=value;
  }
  get dateOfBirth():string{
    return this._dateOfBirth;
  }
  set dateOfBirth(value:string){
    this._dateOfBirth=value;
  }
  get password():string{
    return this._password;
  }
  set password(value:string){
    this._password=value;
  }
  get emailID():string{
    return this._emailID;
  }
  set emailID(value:string){
    this._emailID=value;
  }
  get age():number{
    return this._age;
  }
  set age(value:number){
    this._age=value;
  }
  get mobileNo():number{
    return this._mobileNo;
  }
  set mobileNo(value:number){
    this._mobileNo=value;
  }
  get gender():string{
    return this._gender;
  }
  set gender(value:string){
    this._gender=value;
  }
  get firstSecurityAnswer():string{
    return this._firstSecurityAnswer;
  }
  set firstSecurityAnswer(value:string){
    this._firstSecurityAnswer=value;
  }
  get secondSecurityAnswer():string{
    return this._secondSecurityAnswer;
  }
  set secondSecurityAnswer(value:string){
    this._secondSecurityAnswer=value;
  }
  ngOnInit() {
  }
  
  onClick(){
    const _user:any={
      firstName:this.firstName,
      lastName:this.lastName,
      dateOfBirth:this.dateOfBirth,
      password:this.password,
      emailID:this.emailID,
      age:this.age,
      mobileNo:this.mobileNo,
      gender:this.gender,
      firstSecurityAnswer:this._firstSecurityAnswer,
      secondSecurityAnswer:this._secondSecurityAnswer
    }
    console.log(JSON.stringify(_user))
    this.service.acceptUserDetails(_user).subscribe(
      tempMessage=>{
        this.successMessage="Registration Successful!!"; 
        console.log(this.successMessage)
        } 
    ,
      error=>{
        this.errorMessage=error;
      }
  );
  }

}
